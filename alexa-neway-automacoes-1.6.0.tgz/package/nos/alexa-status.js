module.exports = function (RED) {
    function AlexaStatus(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const account = RED.nodes.getNode(config.account);

        if (!account) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem conta' });
            return;
        }

        let last = null;

        function show(state) {
            if (state.code === 'READY') node.status({ fill: 'green', shape: 'dot', text: 'pronto' });
            else if (state.code === 'WAIT_PROXY') node.status({ fill: 'yellow', shape: 'ring', text: 'login: ' + state.text });
            else if (state.code === 'ERROR' || state.code === 'OFFLINE') node.status({ fill: 'red', shape: 'ring', text: state.code.toLowerCase() });
            else node.status({ fill: 'yellow', shape: 'ring', text: state.code });
        }

        function report(state) {
            show(state);
            if (last === state.code + '|' + state.text) return;
            last = state.code + '|' + state.text;
            node.send({
                topic: 'alexa-status',
                payload: Object.assign({ account: account.name || account.id, needsLogin: state.code === 'WAIT_PROXY' }, state)
            });
        }

        account.on('alexa-state', report);
        show(account.state);

        node.on('input', (msg, send, done) => {
            msg.topic = 'alexa-status';
            msg.payload = Object.assign({ account: account.name || account.id, needsLogin: account.state.code === 'WAIT_PROXY' }, account.diagnostics());
            send(msg);
            done();
        });

        node.on('close', () => account.removeListener('alexa-state', report));
    }

    RED.nodes.registerType('alexa-status', AlexaStatus);
};
