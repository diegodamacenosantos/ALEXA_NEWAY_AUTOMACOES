module.exports = function (RED) {
    function AlexaVolume(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const account = RED.nodes.getNode(config.account);

        if (!account) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem conta' });
            return;
        }

        function show(state) {
            if (state.code === 'READY') return node.status({ fill: 'green', shape: 'dot', text: 'pronto' });
            if (state.code === 'WAIT_PROXY') return node.status({ fill: 'yellow', shape: 'ring', text: 'login: ' + state.text });
            if (state.code === 'ERROR') return node.status({ fill: 'red', shape: 'ring', text: state.text.slice(0, 40) });
            node.status({ fill: 'yellow', shape: 'ring', text: state.code });
        }

        account.on('alexa-state', show);
        show(account.state);

        node.on('close', () => account.removeListener('alexa-state', show));

        node.on('input', async (msg, send, done) => {
            try {
                const device = msg.device || config.device;
                const fixed = String(config.volume === undefined || config.volume === null ? '' : config.volume).trim();
                const incoming = ['string', 'number'].indexOf(typeof msg.payload) !== -1 ? String(msg.payload).trim() : '';
                const raw = msg.volume !== undefined ? String(msg.volume).trim() : (fixed || incoming);
                const level = raw === '' ? NaN : Math.round(Number(raw));

                if (!device) throw new Error('dispositivo nao definido');
                if (!(level >= 1 && level <= 100)) throw new Error('volume de 1 a 100: preencha o no ou envie msg.payload');

                await account.setVolume(device, level);
                node.status({ fill: 'green', shape: 'dot', text: 'volume ' + level });
                msg.payload = { ok: true, device: device, volume: level };
                send(msg);
                done();
            } catch (e) {
                node.status({ fill: 'red', shape: 'dot', text: String(e.message || e).slice(0, 40) });
                done(e);
            }
        });
    }

    RED.nodes.registerType('alexa-volume', AlexaVolume);
};
