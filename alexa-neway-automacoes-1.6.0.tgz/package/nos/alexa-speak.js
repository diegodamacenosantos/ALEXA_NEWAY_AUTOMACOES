module.exports = function (RED) {
    function AlexaSpeak(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const account = RED.nodes.getNode(config.account);

        if (!account) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem conta' });
            return;
        }

        function show(state) {
            if (state.code === 'READY') return node.status({ fill: 'green', shape: 'dot', text: 'pronto' });
            if (state.code === 'WAIT_PROXY') return node.status({ fill: 'yellow', shape: 'ring', text: 'login: ' + state.text });
            if (state.code === 'ERROR') return node.status({ fill: 'red', shape: 'ring', text: state.text.slice(0, 40) });
            node.status({ fill: 'yellow', shape: 'ring', text: state.code });
        }

        account.on('alexa-state', show);
        show(account.state);

        node.on('close', () => account.removeListener('alexa-state', show));

        node.on('input', async (msg, send, done) => {
            try {
                const device = msg.device || config.device;
                const fixed = String(msg.text || config.text || '').trim();
                const incoming = ['string', 'number', 'boolean'].indexOf(typeof msg.payload) !== -1 ? String(msg.payload).trim() : '';
                const text = fixed || incoming;

                if (!device) throw new Error('dispositivo nao definido');
                if (!text) throw new Error('texto vazio: preencha o no ou envie msg.payload');

                await account.speak(device, text);
                node.status({ fill: 'green', shape: 'dot', text: 'falou' });
                msg.payload = { ok: true, device: device, text: text };
                send(msg);
                done();
            } catch (e) {
                node.status({ fill: 'red', shape: 'dot', text: String(e.message || e).slice(0, 40) });
                done(e);
            }
        });
    }

    RED.nodes.registerType('alexa-speak', AlexaSpeak);
};
