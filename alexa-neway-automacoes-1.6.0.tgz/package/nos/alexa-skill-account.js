const fs = require('fs');
const http = require('http');
const path = require('path');
const AlexaRemote = require('alexa-remote2');

const STRIPPED = ['content-security-policy', 'content-security-policy-report-only', 'strict-transport-security'];

if (!http.ServerResponse.prototype.alexaSkillPorts) {
    const ports = new Set();
    const original = http.ServerResponse.prototype.writeHead;
    http.ServerResponse.prototype.alexaSkillPorts = ports;
    http.ServerResponse.prototype.writeHead = function (...args) {
        if (this.socket && ports.has(this.socket.localPort) && !this.headersSent) {
            STRIPPED.forEach(name => this.removeHeader(name));
            const headers = args[args.length - 1];
            if (headers && typeof headers === 'object' && !Array.isArray(headers)) {
                Object.keys(headers).forEach(key => {
                    if (STRIPPED.indexOf(key.toLowerCase()) !== -1) delete headers[key];
                });
            }
        }
        return original.apply(this, args);
    };
}

const BACKOFF = [10000, 30000, 60000, 120000, 300000];
const DAY = 86400000;
const HEALTH_MS = 300000;
const WAIT_READY_MS = 30000;
const COMMAND_MS = 20000;

function validToken(data) {
    return !!data && typeof data === 'object' && (typeof data.localCookie === 'string' || typeof data.cookie === 'string');
}

function parseToken(file) {
    try {
        const data = JSON.parse(fs.readFileSync(file, 'utf8'));
        return validToken(data) ? data : null;
    } catch (e) {
        return null;
    }
}

function readToken(file) {
    return parseToken(file) || parseToken(file + '.bak');
}

function writeToken(file, data) {
    if (!validToken(data)) return false;
    try {
        fs.mkdirSync(path.dirname(file), { recursive: true });
        const current = parseToken(file);
        if (current) {
            if (JSON.stringify(current) === JSON.stringify(data)) return true;
            try {
                fs.copyFileSync(file, file + '.bak');
            } catch (e) {}
        }
        const tmp = file + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(data));
        try {
            fs.renameSync(tmp, file);
        } catch (e) {
            fs.writeFileSync(file, JSON.stringify(data));
            try {
                fs.unlinkSync(tmp);
            } catch (e2) {}
        }
        return true;
    } catch (e) {
        return false;
    }
}

function isNetworkError(err) {
    const text = String((err && err.code) || '') + ' ' + String((err && err.message) || err);
    return /ENOTFOUND|EAI_AGAIN|ETIMEDOUT|ECONNREFUSED|ECONNRESET|EHOSTUNREACH|ENETUNREACH|ENETDOWN|ESOCKETTIMEDOUT|ECONNABORTED|EPIPE|socket hang up|timeout|timed out|getaddrinfo/i.test(text);
}

function isAuthError(err) {
    return /401|Unauthorized|Cookie invalid/i.test(String((err && err.message) || err));
}

module.exports = function (RED) {
    const needsRead = RED.auth.needsPermission('alexa-skill-account.read');

    function findProducts(node, byId) {
        if (Array.isArray(node)) {
            for (const item of node) {
                const found = findProducts(item, byId);
                if (found) return found;
            }
            return null;
        }
        if (node && typeof node === 'object') {
            if (Array.isArray(node.products) && (!byId || node.id === 'skillsPageData')) return node.products;
            for (const key of Object.keys(node)) {
                const found = findProducts(node[key], byId);
                if (found) return found;
            }
        }
        return null;
    }

    function parseSkills(res) {
        let data = res;
        if (typeof data === 'string') {
            try {
                data = JSON.parse(data);
            } catch (e) {
                return [];
            }
        }
        const products = findProducts(data, true) || findProducts(data, false) || [];
        return products
            .map(p => {
                const meta = (p && p.productMetadata) || {};
                const details = (p && p.productDetails) || {};
                return {
                    id: meta.skillId || (p && p.id),
                    name: (p && (p.title || p.name)) || '',
                    stage: meta.stage || '',
                    invocation: details.invocationPhrase || ''
                };
            })
            .filter(s => s.id && s.name)
            .sort((a, b) => a.name.localeCompare(b.name));
    }

    function AlexaSkillAccount(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.setMaxListeners(0);
        const language = config.acceptLanguage || 'en-US';
        const amazonPage = config.amazonPage || 'amazon.com';
        const port = Number(config.proxyPort) || 3456;
        const ownIp = config.proxyOwnIp || 'localhost';
        const days = Number(config.refreshDays) || 0;
        const cookieFile = config.cookieFile || path.join(RED.settings.userDir || '.', 'alexa-skill-cookie-' + node.id + '.json');

        node.alexa = null;
        node.state = { code: 'INIT', text: '' };
        node.since = Date.now();
        node.cookieFile = cookieFile;

        const diag = { lastOk: null, lastRefresh: null, lastError: '', attempts: 0, nextRetry: null };
        let generation = 0;
        let attempt = 0;
        let rejects = 0;
        let retryTimer = null;
        let healthTimer = null;
        let refreshTimer = null;

        function setState(code, text) {
            if (node.state.code !== code) node.since = Date.now();
            node.state = { code: code, text: text || '' };
            node.emit('alexa-state', node.state);
        }

        function clearRetry() {
            if (retryTimer) clearTimeout(retryTimer);
            retryTimer = null;
            diag.nextRetry = null;
        }

        function dispose(alexa) {
            if (!alexa) return;
            try {
                if (typeof alexa.stop === 'function') alexa.stop();
            } catch (e) {}
        }

        function stopProxy() {
            try {
                if (node.alexa && typeof node.alexa.stopProxyServer === 'function') node.alexa.stopProxyServer();
            } catch (e) {}
        }

        function makeOptions(saved) {
            const options = {
                proxyOnly: true,
                setupProxy: true,
                proxyOwnIp: ownIp,
                proxyPort: port,
                proxyLogLevel: 'warn',
                bluetooth: false,
                usePushConnection: false,
                cookieRefreshInterval: 0,
                amazonPage: amazonPage,
                alexaServiceHost: config.alexaServiceHost || undefined,
                acceptLanguage: language,
                amazonPageProxyLanguage: language.replace('-', '_'),
                userAgent: config.userAgent || undefined,
                apiUserAgentPostfix: 'node-red-contrib-alexa-skill',
                logger: message => node.trace(message)
            };
            if (saved) {
                const copy = JSON.parse(JSON.stringify(saved));
                options.cookie = copy;
                options.formerRegistrationData = copy;
            }
            return options;
        }

        function refreshToken(saved) {
            return new Promise(resolve => {
                if (!saved.refreshToken || !saved.loginCookie) {
                    return resolve({ ok: false, err: new Error('token sem dados de renovacao') });
                }
                const helper = new AlexaRemote();
                helper._options = makeOptions(saved);
                let finished = false;
                const timer = setTimeout(() => {
                    if (finished) return;
                    finished = true;
                    resolve({ ok: false, err: new Error('timeout na renovacao') });
                }, 45000);
                try {
                    helper.refreshCookie((err, res) => {
                        if (finished) return;
                        finished = true;
                        clearTimeout(timer);
                        if (err || !validToken(res)) return resolve({ ok: false, err: err || new Error('renovacao sem cookie') });
                        resolve({ ok: true, data: res });
                    });
                } catch (e) {
                    finished = true;
                    clearTimeout(timer);
                    resolve({ ok: false, err: e });
                }
            });
        }

        function scheduleRetry(background) {
            clearRetry();
            const delay = BACKOFF[Math.min(attempt, BACKOFF.length - 1)];
            attempt++;
            diag.nextRetry = Date.now() + delay;
            retryTimer = setTimeout(() => {
                retryTimer = null;
                diag.nextRetry = null;
                establish(background, false);
            }, delay);
        }

        function fail(code, message, background) {
            diag.lastError = message;
            node.warn(message);
            if (!background || node.state.code !== 'READY') setState(code, message);
            scheduleRetry(background);
        }

        function adopt(alexa) {
            const old = node.alexa;
            node.alexa = alexa;
            if (old && old !== alexa) dispose(old);
            attempt = 0;
            rejects = 0;
            alexa.lastAuthCheck = Date.now();
            diag.lastOk = Date.now();
            diag.lastError = '';
            setState('READY', '');
        }

        function open(saved, my, background) {
            const alexa = new AlexaRemote();
            http.ServerResponse.prototype.alexaSkillPorts.add(port);
            alexa.on('cookie', () => {
                if (my === generation) writeToken(cookieFile, alexa.cookieData);
            });
            alexa.init(makeOptions(saved), err => {
                if (my !== generation) {
                    dispose(alexa);
                    return;
                }
                if (err) {
                    const message = String(err.message || err);
                    if (/https?:\/\//i.test(message) && /(open|visit|browser)/i.test(message)) {
                        const url = 'http://' + ownIp + ':' + port;
                        clearRetry();
                        if (node.alexa && node.alexa !== alexa) dispose(node.alexa);
                        node.alexa = alexa;
                        diag.lastError = 'login necessario';
                        node.warn('abra ' + url + ' no navegador e faca login na Amazon');
                        setState('WAIT_PROXY', url);
                        return;
                    }
                    dispose(alexa);
                    fail(isNetworkError(err) ? 'OFFLINE' : 'ERROR', message, background);
                    return;
                }
                writeToken(cookieFile, alexa.cookieData);
                adopt(alexa);
            });
        }

        function establish(background, force) {
            const my = ++generation;
            clearRetry();
            const saved = readToken(cookieFile);
            if (!background) setState('INIT', '');
            if (!saved) {
                stopProxy();
                open(null, my, false);
                return;
            }
            const fresh = saved.tokenDate && Date.now() - saved.tokenDate < DAY && saved.macDms && saved.dataVersion === 2;
            if (fresh && !force) {
                open(saved, my, background);
                return;
            }
            diag.attempts++;
            refreshToken(saved).then(result => {
                if (my !== generation) return;
                if (!result.ok) {
                    const message = String((result.err && result.err.message) || result.err);
                    if (isNetworkError(result.err)) {
                        rejects = 0;
                        fail('OFFLINE', 'sem rede: ' + message, background);
                        return;
                    }
                    rejects++;
                    if (rejects >= 3) {
                        diag.lastError = 'token recusado: ' + message;
                        stopProxy();
                        open(null, my, false);
                        return;
                    }
                    fail('ERROR', 'renovacao recusada (' + rejects + '/3): ' + message, background);
                    return;
                }
                rejects = 0;
                diag.lastRefresh = Date.now();
                writeToken(cookieFile, result.data);
                open(result.data, my, background);
            });
        }

        function health() {
            const alexa = node.alexa;
            if (node.state.code !== 'READY' || !alexa) return;
            alexa.checkAuthentication((ok, err) => {
                if (alexa !== node.alexa || node.state.code !== 'READY') return;
                if (ok) {
                    alexa.lastAuthCheck = Date.now();
                    diag.lastOk = Date.now();
                    return;
                }
                if (ok === null) {
                    diag.lastError = 'verificacao sem resposta: ' + String((err && err.message) || err);
                    return;
                }
                node.warn('sessao invalida, renovando token');
                establish(false, true);
            });
        }

        function waitReady() {
            return new Promise((resolve, reject) => {
                const refuse = () => reject(new Error('conta nao pronta: ' + node.state.code + (node.state.text ? ' ' + node.state.text : '')));
                if (node.state.code === 'READY' && node.alexa) return resolve(node.alexa);
                if (['INIT', 'OFFLINE', 'ERROR'].indexOf(node.state.code) === -1) return refuse();
                let timer = null;
                const listener = state => {
                    if (state.code === 'READY' && node.alexa) {
                        clearTimeout(timer);
                        node.removeListener('alexa-state', listener);
                        resolve(node.alexa);
                    } else if (state.code === 'WAIT_PROXY') {
                        clearTimeout(timer);
                        node.removeListener('alexa-state', listener);
                        refuse();
                    }
                };
                timer = setTimeout(() => {
                    node.removeListener('alexa-state', listener);
                    refuse();
                }, WAIT_READY_MS);
                node.on('alexa-state', listener);
            });
        }

        function execute(run, retried) {
            return waitReady()
                .then(alexa => new Promise((resolve, reject) => {
                    const timer = setTimeout(() => reject(new Error('tempo esgotado')), COMMAND_MS);
                    run(alexa, err => {
                        clearTimeout(timer);
                        if (err && String(err.message || err) !== 'no body') return reject(err);
                        resolve();
                    });
                }))
                .catch(e => {
                    if (!retried && isAuthError(e)) {
                        establish(false, true);
                        return execute(run, true);
                    }
                    throw e;
                });
        }

        function ready() {
            if (node.state.code !== 'READY' || !node.alexa) {
                throw new Error('conta nao pronta: ' + node.state.code + (node.state.text ? ' ' + node.state.text : ''));
            }
            return node.alexa;
        }

        const fetchSkills = () => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            const parts = language.split('-');
            const url = 'https://skills-store.' + amazonPage + '/app/secure/your-skills-page?deviceType=app&ref-suffix=ysa_gw&pfm=A1PA6795UKMFR9&cor=' +
                (parts[1] || 'US').toUpperCase() + '&lang=' + language.toLowerCase() + '&_=%t';
            alexa.httpsGet(url, (err, res) => {
                if (err) return reject(err);
                resolve(res);
            }, { method: 'GET', headers: { Accept: 'application/vnd+amazon.uitoolkit+json;ns=1;fl=0' } });
        });

        node.getSkills = () => fetchSkills().then(parseSkills);

        node.getSkillsRaw = () => fetchSkills().then(res => {
            const text = typeof res === 'string' ? res : JSON.stringify(res);
            return { length: text.length, text: text.slice(0, 6000) };
        });

        node.getDevices = () => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            const list = Object.values(alexa.serialNumbers || {})
                .map(d => ({
                    serial: d.serialNumber,
                    name: d.accountName,
                    type: d.deviceTypeFriendlyName || d.deviceType,
                    deviceType: d.deviceType,
                    online: d.online
                }))
                .filter(d => d.serial && d.name && d.deviceType !== 'A2IVLV5VM2W81')
                .sort((a, b) => a.name.localeCompare(b.name));
            resolve(list);
        });

        node.launch = (device, skill) => execute((alexa, done) => alexa.sendSequenceCommand(device, 'skill', skill, done));

        node.speak = (device, text) => execute((alexa, done) => alexa.sendSequenceCommand(device, 'speak', text, done));

        node.sendCommand = (device, text) => execute((alexa, done) => alexa.sendSequenceCommand(device, 'textCommand', text, done));

        node.setVolume = (device, level) => execute((alexa, done) => alexa.sendSequenceCommand(device, 'volume', level, done));

        node.diagnostics = () => {
            const saved = readToken(cookieFile);
            return {
                state: node.state.code,
                text: node.state.text,
                since: node.since,
                tokenDate: saved && saved.tokenDate ? saved.tokenDate : null,
                tokenAgeHours: saved && saved.tokenDate ? Math.round((Date.now() - saved.tokenDate) / 360000) / 10 : null,
                tokenFile: cookieFile,
                tokenFileOk: !!saved,
                lastOk: diag.lastOk,
                lastRefresh: diag.lastRefresh,
                lastError: diag.lastError,
                attempts: diag.attempts,
                nextRetry: diag.nextRetry
            };
        };

        healthTimer = setInterval(health, HEALTH_MS);
        if (days > 0) refreshTimer = setInterval(() => {
            if (node.state.code === 'READY') establish(true, true);
        }, days * DAY);

        node.on('close', done => {
            generation++;
            clearRetry();
            if (healthTimer) clearInterval(healthTimer);
            if (refreshTimer) clearInterval(refreshTimer);
            stopProxy();
            dispose(node.alexa);
            node.alexa = null;
            done();
        });

        establish(false, false);
    }

    RED.nodes.registerType('alexa-skill-account', AlexaSkillAccount);

    function answer(method) {
        return (req, res) => {
            const account = RED.nodes.getNode(req.query.id);
            if (!account || typeof account[method] !== 'function') {
                return res.status(400).json({ error: 'conta nao implantada, faca o deploy' });
            }
            Promise.resolve().then(() => account[method]()).then(list => res.json(list)).catch(e => res.status(500).json({ error: e.message }));
        };
    }

    RED.httpAdmin.get('/alexa-skill/skills', needsRead, answer('getSkills'));
    RED.httpAdmin.get('/alexa-skill/devices', needsRead, answer('getDevices'));
    RED.httpAdmin.get('/alexa-skill/raw', needsRead, answer('getSkillsRaw'));
    RED.httpAdmin.get('/alexa-skill/diag', needsRead, answer('diagnostics'));
    RED.httpAdmin.get('/alexa-skill/state', needsRead, (req, res) => {
        const account = RED.nodes.getNode(req.query.id);
        if (!account) return res.status(400).json({ error: 'conta nao implantada, faca o deploy' });
        res.json(account.state);
    });
};
