module.exports = function (RED) {
    function AlexaSkill(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const account = RED.nodes.getNode(config.account);

        if (!account) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem conta' });
            return;
        }

        function show(state) {
            if (state.code === 'READY') return node.status({ fill: 'green', shape: 'dot', text: 'pronto' });
            if (state.code === 'WAIT_PROXY') return node.status({ fill: 'yellow', shape: 'ring', text: 'login: ' + state.text });
            if (state.code === 'ERROR') return node.status({ fill: 'red', shape: 'ring', text: state.text.slice(0, 40) });
            node.status({ fill: 'yellow', shape: 'ring', text: state.code });
        }

        account.on('alexa-state', show);
        show(account.state);

        node.on('close', () => account.removeListener('alexa-state', show));

        node.on('input', async (msg, send, done) => {
            try {
                const device = msg.device || config.device;
                const typed = msg.skill;
                let skill = typed || config.skill;
                let skillName = typed || config.skillName;

                if (!device) throw new Error('dispositivo nao definido');
                if (!skill) throw new Error('skill nao definida');

                if (typed && !/^amzn1\./.test(typed)) {
                    const list = await account.getSkills();
                    const found = list.find(s => s.name.toLowerCase() === typed.toLowerCase());
                    if (!found) throw new Error('use o id (amzn1.ask.skill...) para skill fora da lista: ' + typed);
                    skill = found.id;
                    skillName = found.name;
                }

                await account.launch(device, skill);
                node.status({ fill: 'green', shape: 'dot', text: 'ok: ' + (skillName || skill) });
                msg.payload = { ok: true, skill: skill, device: device };
                send(msg);
                done();
            } catch (e) {
                node.status({ fill: 'red', shape: 'dot', text: String(e.message || e).slice(0, 40) });
                done(e);
            }
        });
    }

    RED.nodes.registerType('alexa-skill', AlexaSkill);
};
