module.exports = function (RED) {
    function Alexa(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const account = RED.nodes.getNode(config.account);
        const tipo = config.tipo || 'skill';

        if (!account) {
            node.status({ fill: 'red', shape: 'ring', text: 'sem conta' });
            return;
        }

        function show(state) {
            if (state.code === 'READY') return node.status({ fill: 'green', shape: 'dot', text: 'pronto' });
            if (state.code === 'WAIT_PROXY') return node.status({ fill: 'yellow', shape: 'ring', text: 'login: ' + state.text });
            if (state.code === 'ERROR') return node.status({ fill: 'red', shape: 'ring', text: state.text.slice(0, 40) });
            node.status({ fill: 'yellow', shape: 'ring', text: state.code });
        }

        account.on('alexa-state', show);
        show(account.state);

        node.on('close', () => account.removeListener('alexa-state', show));

        function text(value) {
            return ['string', 'number', 'boolean'].indexOf(typeof value) !== -1 ? String(value).trim() : '';
        }

        function configured(raw, type, msg) {
            const key = String(raw === undefined || raw === null ? '' : raw).trim();
            if (type === 'msg' && key) return { own: true, value: text(RED.util.getMessageProperty(msg, key)) };
            return { own: false, value: key };
        }

        async function runSkill(msg) {
            const device = msg.device || config.device;
            const skill = config.skill;

            if (!device) throw new Error('dispositivo nao definido');
            if (!skill) throw new Error('skill nao definida');

            await account.launch(device, skill);
            node.status({ fill: 'green', shape: 'dot', text: 'ok: ' + (config.skillName || skill) });
            msg.payload = { ok: true, skill: skill, device: device };
        }

        async function runSpeak(msg) {
            const device = msg.device || config.device;
            const set = configured(config.text, config.textType, msg);
            const spoken = set.own ? set.value : (set.value || text(msg.payload));

            if (!device) throw new Error('dispositivo nao definido');
            if (!spoken) throw new Error('texto vazio: preencha o no ou envie msg.payload');

            await account.speak(device, spoken);
            node.status({ fill: 'green', shape: 'dot', text: 'falou' });
            msg.payload = { ok: true, device: device, text: spoken };
        }

        async function runVolume(msg) {
            const device = msg.device || config.device;
            const set = configured(config.volume, config.volumeType, msg);
            const incoming = ['string', 'number'].indexOf(typeof msg.payload) !== -1 ? String(msg.payload).trim() : '';
            const raw = set.own ? set.value : (set.value || incoming);
            const level = raw === '' ? NaN : Math.round(Number(raw));

            if (!device) throw new Error('dispositivo nao definido');
            if (!(level >= 1 && level <= 100)) throw new Error('volume de 1 a 100: preencha o no ou envie msg.payload');

            await account.setVolume(device, level);
            node.status({ fill: 'green', shape: 'dot', text: 'volume ' + level });
            msg.payload = { ok: true, device: device, volume: level };
        }

        async function runCommand(msg) {
            const device = msg.device || config.device;
            const set = configured(config.command, config.commandType, msg);
            const command = set.own ? set.value : (set.value || text(msg.payload));

            if (!device) throw new Error('dispositivo nao definido');
            if (!command) throw new Error('comando vazio: preencha o no ou envie msg.payload');

            await account.sendCommand(device, command);
            node.status({ fill: 'green', shape: 'dot', text: 'enviado' });
            msg.payload = { ok: true, device: device, command: command };
        }

        const runners = { skill: runSkill, speak: runSpeak, volume: runVolume, command: runCommand };

        node.on('input', async (msg, send, done) => {
            try {
                await (runners[tipo] || runSkill)(msg);
                send(msg);
                done();
            } catch (e) {
                node.status({ fill: 'red', shape: 'dot', text: String(e.message || e).slice(0, 40) });
                done(e);
            }
        });
    }

    RED.nodes.registerType('alexa-neway', Alexa);
};
