const fs = require('fs');
const http = require('http');
const path = require('path');
const AlexaRemote = require('alexa-remote2');

const STRIPPED = ['content-security-policy', 'content-security-policy-report-only', 'strict-transport-security'];

if (!http.ServerResponse.prototype.alexaSkillPorts) {
    const ports = new Set();
    const original = http.ServerResponse.prototype.writeHead;
    http.ServerResponse.prototype.alexaSkillPorts = ports;
    http.ServerResponse.prototype.writeHead = function (...args) {
        if (this.socket && ports.has(this.socket.localPort) && !this.headersSent) {
            STRIPPED.forEach(name => this.removeHeader(name));
            const headers = args[args.length - 1];
            if (headers && typeof headers === 'object' && !Array.isArray(headers)) {
                Object.keys(headers).forEach(key => {
                    if (STRIPPED.indexOf(key.toLowerCase()) !== -1) delete headers[key];
                });
            }
        }
        return original.apply(this, args);
    };
}

module.exports = function (RED) {
    const needsRead = RED.auth.needsPermission('alexa-skill-account.read');

    function readCookie(file) {
        try {
            return JSON.parse(fs.readFileSync(file, 'utf8'));
        } catch (e) {
            return null;
        }
    }

    function writeCookie(file, data) {
        if (!data) return;
        fs.mkdirSync(path.dirname(file), { recursive: true });
        fs.writeFileSync(file, JSON.stringify(data));
    }

    function findProducts(node, byId) {
        if (Array.isArray(node)) {
            for (const item of node) {
                const found = findProducts(item, byId);
                if (found) return found;
            }
            return null;
        }
        if (node && typeof node === 'object') {
            if (Array.isArray(node.products) && (!byId || node.id === 'skillsPageData')) return node.products;
            for (const key of Object.keys(node)) {
                const found = findProducts(node[key], byId);
                if (found) return found;
            }
        }
        return null;
    }

    function parseSkills(res) {
        let data = res;
        if (typeof data === 'string') {
            try {
                data = JSON.parse(data);
            } catch (e) {
                return [];
            }
        }
        const products = findProducts(data, true) || findProducts(data, false) || [];
        return products
            .map(p => {
                const meta = (p && p.productMetadata) || {};
                const details = (p && p.productDetails) || {};
                return {
                    id: meta.skillId || (p && p.id),
                    name: (p && (p.title || p.name)) || '',
                    stage: meta.stage || '',
                    invocation: details.invocationPhrase || ''
                };
            })
            .filter(s => s.id && s.name)
            .sort((a, b) => a.name.localeCompare(b.name));
    }

    function AlexaSkillAccount(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        const language = config.acceptLanguage || 'en-US';
        const amazonPage = config.amazonPage || 'amazon.com';
        const port = Number(config.proxyPort) || 3456;
        const ownIp = config.proxyOwnIp || 'localhost';
        const days = Number(config.refreshDays) || 0;
        const cookieFile = config.cookieFile || path.join(RED.settings.userDir || '.', 'alexa-skill-cookie-' + node.id + '.json');

        node.alexa = null;
        node.state = { code: 'UNINITIALISED', text: '' };
        node.cookieFile = cookieFile;

        function setState(code, text) {
            node.state = { code: code, text: text || '' };
            node.emit('alexa-state', node.state);
        }

        function stop() {
            const alexa = node.alexa;
            node.alexa = null;
            if (!alexa) return;
            try {
                if (typeof alexa.stop === 'function') alexa.stop();
            } catch (e) {}
            try {
                if (typeof alexa.stopProxyServer === 'function') alexa.stopProxyServer();
            } catch (e) {}
        }

        function start() {
            stop();
            const saved = readCookie(cookieFile);
            http.ServerResponse.prototype.alexaSkillPorts.add(port);
            const alexa = new AlexaRemote();
            node.alexa = alexa;
            const options = {
                proxyOnly: true,
                setupProxy: true,
                proxyOwnIp: ownIp,
                proxyPort: port,
                proxyLogLevel: 'warn',
                bluetooth: false,
                usePushConnection: false,
                cookieRefreshInterval: 0,
                amazonPage: amazonPage,
                alexaServiceHost: config.alexaServiceHost || undefined,
                acceptLanguage: language,
                amazonPageProxyLanguage: language.replace('-', '_'),
                userAgent: config.userAgent || undefined,
                apiUserAgentPostfix: 'node-red-contrib-alexa-skill',
                logger: () => {}
            };
            if (saved) {
                options.cookie = saved;
                options.formerRegistrationData = saved;
            }
            setState('INIT', '');
            alexa.on('cookie', () => {
                if (alexa === node.alexa) writeCookie(cookieFile, alexa.cookieData);
            });
            alexa.init(options, err => {
                if (alexa !== node.alexa) return;
                if (err) {
                    const message = String(err.message || err);
                    if (/https?:\/\//i.test(message) && /(open|visit|browser)/i.test(message)) {
                        const url = 'http://' + ownIp + ':' + port;
                        node.warn('abra ' + url + ' no navegador e faca login na Amazon');
                        setState('WAIT_PROXY', url);
                        return;
                    }
                    node.error(message);
                    setState('ERROR', message);
                    return;
                }
                writeCookie(cookieFile, alexa.cookieData);
                setState('READY', '');
            });
        }

        function ready() {
            if (node.state.code !== 'READY' || !node.alexa) {
                throw new Error('conta nao pronta: ' + node.state.code + (node.state.text ? ' ' + node.state.text : ''));
            }
            return node.alexa;
        }

        const fetchSkills = () => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            const parts = language.split('-');
            const url = 'https://skills-store.' + amazonPage + '/app/secure/your-skills-page?deviceType=app&ref-suffix=ysa_gw&pfm=A1PA6795UKMFR9&cor=' +
                (parts[1] || 'US').toUpperCase() + '&lang=' + language.toLowerCase() + '&_=%t';
            alexa.httpsGet(url, (err, res) => {
                if (err) return reject(err);
                resolve(res);
            }, { method: 'GET', headers: { Accept: 'application/vnd+amazon.uitoolkit+json;ns=1;fl=0' } });
        });

        node.getSkills = () => fetchSkills().then(parseSkills);

        node.getSkillsRaw = () => fetchSkills().then(res => {
            const text = typeof res === 'string' ? res : JSON.stringify(res);
            return { length: text.length, text: text.slice(0, 6000) };
        });

        node.getDevices = () => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            const list = Object.values(alexa.serialNumbers || {})
                .map(d => ({
                    serial: d.serialNumber,
                    name: d.accountName,
                    type: d.deviceTypeFriendlyName || d.deviceType,
                    deviceType: d.deviceType,
                    online: d.online
                }))
                .filter(d => d.serial && d.name && d.deviceType !== 'A2IVLV5VM2W81')
                .sort((a, b) => a.name.localeCompare(b.name));
            resolve(list);
        });

        node.launch = (device, skill) => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            alexa.sendSequenceCommand(device, 'skill', skill, err => {
                if (err && String(err.message || err) !== 'no body') return reject(err);
                resolve();
            });
        });

        node.speak = (device, text) => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            alexa.sendSequenceCommand(device, 'speak', text, err => {
                if (err && String(err.message || err) !== 'no body') return reject(err);
                resolve();
            });
        });

        node.sendCommand = (device, text) => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            alexa.sendSequenceCommand(device, 'textCommand', text, err => {
                if (err && String(err.message || err) !== 'no body') return reject(err);
                resolve();
            });
        });

        node.setVolume =(device, level) => new Promise((resolve, reject) => {
            let alexa;
            try {
                alexa = ready();
            } catch (e) {
                return reject(e);
            }
            alexa.sendSequenceCommand(device, 'volume', level, err => {
                if (err && String(err.message || err) !== 'no body') return reject(err);
                resolve();
            });
        });

        node.refreshTimer = null;
        if (days > 0) node.refreshTimer = setInterval(() => {
            if (node.state.code === 'READY') start();
        }, days * 86400000);

        node.on('close', done => {
            if (node.refreshTimer) clearInterval(node.refreshTimer);
            stop();
            done();
        });

        start();
    }

    RED.nodes.registerType('alexa-skill-account', AlexaSkillAccount);

    function answer(method) {
        return (req, res) => {
            const account = RED.nodes.getNode(req.query.id);
            if (!account || typeof account[method] !== 'function') {
                return res.status(400).json({ error: 'conta nao implantada, faca o deploy' });
            }
            account[method]().then(list => res.json(list)).catch(e => res.status(500).json({ error: e.message }));
        };
    }

    RED.httpAdmin.get('/alexa-skill/skills', needsRead, answer('getSkills'));
    RED.httpAdmin.get('/alexa-skill/devices', needsRead, answer('getDevices'));
    RED.httpAdmin.get('/alexa-skill/raw', needsRead, answer('getSkillsRaw'));
    RED.httpAdmin.get('/alexa-skill/state', needsRead, (req, res) => {
        const account = RED.nodes.getNode(req.query.id);
        if (!account) return res.status(400).json({ error: 'conta nao implantada, faca o deploy' });
        res.json(account.state);
    });
};
